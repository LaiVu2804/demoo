package com.example.gk.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.gk.entity.Book;
import com.example.gk.repository.BookRepository;
import com.example.gk.service.BookService;



@Controller
public class BookController{
	
	private final BookService bookService;
	
	private BookController(BookService bookService) {
		this.bookService = bookService;
	}
	
	@RequestMapping("/home")
	public String getHomePage(Model model) {  

		List<Book> arrBooks = this.bookService.getAllBooks();
		model.addAttribute("books",arrBooks);
		
		return "hello";
	}
	
	
	@RequestMapping("/create/books")
	public String getAddBooks(Model model) { 
		model.addAttribute("newBook",new Book());
		
		return "create/add";
	}
	
	@RequestMapping(value="/create/books", method = RequestMethod.POST)
	public String getALLBooks(Model model, @ModelAttribute("newBook") Book laivu) {
		
		this.bookService.saveBooks(laivu);
		return "redirect:/home";
	}
	
	@RequestMapping("/update/books/{idsach}")
	public String UpdateBooks(Model model, @PathVariable String idsach) {
		Book currentBook = this.bookService.getBookById(idsach);
		model.addAttribute("newBook",currentBook);
		
		return "create/update";
	}
	
}
