package com.example.gk.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

@Entity
@Table(name = "books")
public class Book {

	@Id
	@Column(length = 10)
	private String idsach;

	@Column(columnDefinition = "NVARCHAR(30)")
	private String tensach;

	@Column(columnDefinition = "NVARCHAR(50)")
	private String tacgia;

	@Column
	private double gia;

	@Min(1)
	@Max(2)
	@JsonProperty("uuTien")
	private int uuTien;
	
	@Override
	public String toString() {
		return "Book [idsach=" + idsach + ", tensach=" + tensach + ", tacgia=" + tacgia + ", gia=" + gia + ", uuTien="
				+ uuTien + "]";
	}

	public Book() {

	}

	public String getIdsach() {
		return idsach;
	}

	public void setIdsach(String idsach) {
		this.idsach = idsach;
	}

	public String getTensach() {
		return tensach;
	}

	public void setTensach(String tensach) {
		this.tensach = tensach;
	}

	public String getTacgia() {
		return tacgia;
	}

	public void setTacgia(String tacgia) {
		this.tacgia = tacgia;
	}

	public double getGia() {
		return gia;
	}

	public void setGia(double gia) {
		this.gia = gia;
	}

	public int getUuTien() {
		return uuTien;
	}

	public void setUuTien(int uuTien) {
		this.uuTien = uuTien;
	}
	
}
