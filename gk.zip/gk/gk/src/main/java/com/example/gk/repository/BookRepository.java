package com.example.gk.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.gk.entity.Book;

@Repository
public interface BookRepository extends JpaRepository<Book,String> {
	Book save(Book laivu);
	
	Book getById(String idsach);
	
	boolean existsByIdsach(String idsach);
}
