package com.example.gk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GkApplicationTests {

	@Test
	void contextLoads() {
	}

}
